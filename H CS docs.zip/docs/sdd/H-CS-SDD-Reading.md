# Reading from a File

If the number of lines to be read from a file is known then a fixed loop can be used, otherwise a conditional loop can be used.  Alternatively, the unknown number of lines can be counted, and then a fixed loop used.

File are opened in read mode (`r`).


## Fixed loop

``` python
# Initialise variable
line: str = ""

# Make a connection to the file
file = open("people.csv" ,"r", encoding="utf-8")

# Loop for each line in the file
for index in range(4):

    # Read a line
    line = file.readline()

    """Additional code goes here."""
    print(line)

# Close the connection to the file
file.close()
```


## For each loop

``` python
# Make a connection to the file
file = open("people.csv" ,"r", encoding="utf-8")

# Loop for each line in the file
for line in file:

    """Additional code goes here."""
    primt(line)

# Close the connection to the file
file.close()
```


## Conditional loop

``` python
# Make a connection to the file
file = open("people.csv" ,"r", encoding="utf-8")

# Read first line from the file
line = file.readline()

# Loop if variable not empty
while line != "":

    """Additional code goes here."""
    print(line)

    # Read next line
    line = file.readline()

# Close the connection to the file
file.close()
```


## Counting lines in a file

``` python
# Initialise variables
line: str = ""
count: int = 0

# Make a connection to the file
file = open("people.csv" ,"r", encoding="utf-8")

# Read first line from the file
line = file.readline()

# Loop if variable not empty
while line != "":

    # Read next line
    line = file.readline()

    # Incrememnt count
    count = count + 1

# Close the connection to the file
file.close()
```


## Reading parallel arrays from a file

**Note:** An assumption is that the maximum array size is known, and the file contains that number of rows or fewer.

Declare parallel arrays that are large enough to hold the data.

``` python
# Initialise data structures
names: list[str] = ["" for index in range (4)]
ages: list[int] = [0 for index in range (4)]
heights: list[float] = [0.0 for index in range (4)]
data: list[str] = ["" for index in range (3)]

# Initialise variable
line: str = ""

# Make a connection to the file
file = open("people.csv" ,"r", encoding="utf-8")

# Loop for each line in the file
for index in range(4):

    # Read a line from the file
    line = file.readline()
    
    # Split the line at the commas
    data = line.split(",")

    # 1. Remove non-printing characters
    # 2. Cast as appropriate
    # 3. Assign to data structure
    names[index] = data[0].strip()
    ages[index] = int(data[1].strip())
    heights[index] = float(data[2].strip())

# Close the connection to the file
file.close()
```


## Reading an array of records from a file

**Note:** An assumption is that the maximum array size is known, and the file contains that number of rows or fewer.

Declare an array of records large enough to hold the data.

``` python
# Initialise data structures
people = [Person() for index in range(4)]
data: list[str] = ["" for index in range (3)]

# Initialise variable
line: str = ""

# Make a connection to the file
file = open("people.csv" ,"r", encoding="utf-8")

# Loop for each line in the file
for index in range(4):

    # Read a line from the file
    line = file.readline()
    
    # Split the line at the commas
    data = line.split(",")

    # 1. Remove non-printing characters
    # 2. Cast as appropriate
    # 3. Assign to data structure
    people[index].name = data[0].strip()
    people[index].age = int(data[1].strip())
    people[index].height = float(data[2].strip())

# Close the connection to the file
file.close()
```
